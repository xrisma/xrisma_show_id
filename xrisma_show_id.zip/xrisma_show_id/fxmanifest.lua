fx_version 'cerulean'
game 'gta5'

author 'xrisma scripts'
description 'ESX Legacy script Show Player ID'
version '1.0.0'

client_scripts {
    'client/main.lua'
}

dependencies {
    'es_extended'
}
