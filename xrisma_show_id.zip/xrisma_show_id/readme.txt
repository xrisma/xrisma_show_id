## Preview Join Discord
https://discord.gg/vvwzB8AhAN

Please Rating Discord Server.
⭐⭐⭐⭐⭐

## Features
- **Command-Based Activation**: Players can type `/id` in chat to display their server ID.
- **Temporary Display**: The ID is displayed on-screen for 15 seconds before disappearing automatically.
- **User-Friendly Design**: Designed to work seamlessly with any FiveM server setup.

## Usage

1. In the game chat, type `/id` to activate the feature.
2. Your server ID will appear on the screen for 15 seconds.
3. After 15 seconds, the display will automatically deactivate.

## Customization

You can modify the script to adjust the behavior or appearance of the ID display:
- **Display Duration**: Change the `15000` value in the script to alter the duration (measured in milliseconds).
- **Positioning**: Modify the coordinates used for drawing the text to reposition the ID on the screen.
- **Additional Information**: Add more player-related details (e.g., name, health) to the on-screen display.
