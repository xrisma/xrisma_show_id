local display = false

RegisterCommand('id', function()
    display = true
    local startTime = GetGameTimer()

    Citizen.CreateThread(function()
        while display do
            local currentTime = GetGameTimer()
            if currentTime - startTime > 15000 then
                display = false
            end

            -- Draw the player's ID only
            local playerPed = PlayerPedId()
            local playerId = GetPlayerServerId(PlayerId())
            local coords = GetEntityCoords(playerPed)

            -- Calculate the time for text change
            local elapsedTime = (currentTime - startTime) / 1000
            local displayText = tostring(playerId) -- Only show ID

            -- Draw the player's ID
            DrawText3D(coords.x, coords.y, coords.z + 1.2, displayText, {255, 255, 0, 255})

            -- Draw other players' IDs only
            for _, player in ipairs(GetActivePlayers()) do
                if player ~= PlayerId() then
                    local otherPed = GetPlayerPed(player)
                    local otherCoords = GetEntityCoords(otherPed)
                    local otherId = GetPlayerServerId(player)
                    
                    -- Draw other player's ID
                    DrawText3D(otherCoords.x, otherCoords.y, otherCoords.z + 1.2, tostring(otherId), {255, 255, 0, 255})
                end
            end

            Citizen.Wait(0)
        end
    end)
end, false)

function DrawText3D(x, y, z, text, color)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(color[1], color[2], color[3], color[4])
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end
